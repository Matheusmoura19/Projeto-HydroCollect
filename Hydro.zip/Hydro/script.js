document.addEventListener("DOMContentLoaded", function() {
    // Inicialize o EmailJS com o seu user ID
    emailjs.init("h0Vi-X2qr9ZfAB837"); // Substitua com o seu ID de usuário

    document.getElementById("contact-form").addEventListener("submit", function(event) {
        event.preventDefault();  // Evita que o formulário seja enviado da maneira tradicional

        var form = event.target;
        var formData = new FormData(form); // Coleta os dados do formulário

        // Envia o formulário para o EmailJS
        emailjs.sendForm("service_fdnzyul", "template_ps0iyn8", formData)
            .then(function(response) {
                console.log("Mensagem enviada com sucesso", response);
                document.getElementById("success-message").style.display = "block";  // Exibe a mensagem de sucesso
                form.reset();  // Limpa o formulário após envio
            }, function(error) {
                console.log("Erro ao enviar", error);
                document.getElementById("error-message").style.display = "block";  // Exibe a mensagem de erro
            });
    });
});
